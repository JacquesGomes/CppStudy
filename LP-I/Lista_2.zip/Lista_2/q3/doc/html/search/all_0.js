var searchData=
[
  ['aluno_0',['Aluno',['../classAluno.html',1,'Aluno'],['../classAluno.html#aeb40aeba316824bb67d68f0f49e2c1c5',1,'Aluno::Aluno(int matricula, string nome, float nota1, float nota2, float nota3)'],['../classAluno.html#ad5106d0f7834762fbe5f71f908144336',1,'Aluno::Aluno()']]]
];
