var searchData=
[
  ['calculamedia_8',['calculaMedia',['../classAluno.html#a391a671de9cefbaf531e31fca80230a7',1,'Aluno']]]
];
