var searchData=
[
  ['getnome_2',['getNome',['../classAluno.html#a75ca576e335d4678e6777de92a218b99',1,'Aluno']]]
];
