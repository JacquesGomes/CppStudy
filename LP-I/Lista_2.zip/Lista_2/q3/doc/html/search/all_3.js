var searchData=
[
  ['setnome_3',['setNome',['../classAluno.html#a317539f87c1d2cd5d0228eef9b42bd14',1,'Aluno']]]
];
